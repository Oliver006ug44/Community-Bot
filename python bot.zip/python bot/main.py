from chat_ui import ChatUI
from chatbotClass import ChatBot
import tkinter as tk

class ChatApp:
    def __init__(self, qa_file_path):
        self.qa_file_path = qa_file_path
        self.chatbot = ChatBot(qa_file_path)

    def start(self):
        root = tk.Tk()
        self.chat_ui = ChatUI(root, self.send_user_message)
        root.mainloop()

    def send_user_message(self, user_input):
        if user_input.lower() == 'exit':
            self.chat_ui.display_message("Chatbot: Goodbye! Have a great day.")
            self.chat_ui.disable_input()
        else:
            response = self.chatbot.get_response(user_input)
            self.chat_ui.display_message(f"Chatbot: {response}")

if __name__ == "__main__":
    qa_file_path = "qa_list.txt"  # Replace with the actual file path
    chat_app = ChatApp(qa_file_path)
    chat_app.start()
