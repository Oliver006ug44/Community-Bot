import tkinter as tk

class ChatUI:
    def __init__(self, root, send_callback):
        self.root = root
        self.send_callback = send_callback
        self.root.title("Chatbot UI")

        self.message_box = tk.Text(root, state=tk.DISABLED, wrap=tk.WORD)
        self.message_box.pack(expand=True, fill=tk.BOTH)

        self.input_frame = tk.Frame(root)
        self.input_frame.pack(fill=tk.BOTH)

        self.input_entry = tk.Entry(self.input_frame)
        self.input_entry.pack(side=tk.LEFT, expand=True, fill=tk.BOTH)

        self.send_button = tk.Button(self.input_frame, text="Send", command=self.send_message)
        self.send_button.pack(side=tk.RIGHT)

        self.input_entry.bind("<Return>", self.send_message)

    def send_message(self, event=None):
        user_input = self.input_entry.get()
        if user_input:
            self.display_message(f"You: {user_input}")
            self.send_callback(user_input)
            self.input_entry.delete(0, tk.END)

    def display_message(self, message):
        self.message_box.configure(state=tk.NORMAL)
        self.message_box.insert(tk.END, message + "\n")
        self.message_box.configure(state=tk.DISABLED)
        self.message_box.see(tk.END)

    def disable_input(self):
        self.input_entry.config(state=tk.DISABLED)
        self.send_button.config(state=tk.DISABLED)

    def enable_input(self):
        self.input_entry.config(state=tk.NORMAL)
        self.send_button.config(state=tk.NORMAL)
