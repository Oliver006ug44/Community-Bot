import os
import difflib

class ChatBot:
    def __init__(self, qa_file_path):
        self.qa_file_path = qa_file_path
        self.qa_dict = self.load_qa_from_file(qa_file_path)
        self.similarity_threshold = 0.6  # Adjust the threshold as needed

    def load_qa_from_file(self, file_path):
        qa_dict = {}
        try:
            with open(file_path, 'r') as file:
                for line in file:
                    parts = line.strip().split('|')
                    if len(parts) == 2:
                        question, answer = parts
                        qa_dict[question.lower()] = answer
        except FileNotFoundError:
            print(f"Error: File not found: {file_path}")
        return qa_dict

    def get_response(self, user_input):
        user_input = user_input.lower()

        # Check for specific greetings
        if any(greeting in user_input for greeting in ["hi", "hello", "hey"]):
            return "Sup! How can I help you?"

        # Find the most similar question in the QA dictionary
        matches = difflib.get_close_matches(user_input, self.qa_dict.keys(), n=1, cutoff=self.similarity_threshold)

        if matches:
            matched_question = matches[0]
            return self.qa_dict[matched_question]

        # If no similar question found, fallback to default response
        return "I didn't understand that."

    def reload_qa_list(self):
        self.qa_dict = self.load_qa_from_file(self.qa_file_path)
